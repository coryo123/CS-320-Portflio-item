ContactService.java

package com.test;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;


public class ContactService {

   
   // uniqueId is static int variable at 10 characters
   
   private static int uniqueId=10;
   private static Map<Integer, Contact> contacts = new HashMap<>();

   
    //addContact() method will take contact object and will insert it into map object
   
   public Map<Integer, Contact> addContact(Contact contact) {
       uniqueId++;
       contacts.put(uniqueId, contact);
       return contacts;
   }
  
   
   // deleteContact() method will take contactID and it will search in the map entries and delete it
   

   public Map<Integer, Contact> deleteContact(String contactID) {

       Iterator itr = contacts.entrySet().iterator();

       while (itr.hasNext()) {
           Map.Entry<Integer, Contact> entry = (Map.Entry<Integer, Contact>) itr.next();
           if (entry.getValue().getContactID() == contactID) {
               itr.remove();
           }
       }

       return contacts;

   }
  
   
   // updateContact() method will take the required inputs and update them
    
   public Map<Integer, Contact> updateContact(String contactID, String firstName, String lastName, String number,
           String address) {

       Iterator itr = contacts.entrySet().iterator();

       while (itr.hasNext()) {
           Map.Entry<Integer, Contact> entry = (Map.Entry<Integer, Contact>) itr.next();

           if (entry.getValue().getContactID() == contactID) {
               entry.getValue().setFirstName(firstName);
               entry.getValue().setLastName(lastName);
               entry.getValue().setPhone(number);
               entry.getValue().setAddress(address);
           }

       }

       return contacts;

   }
}